---
name: Bug report
about: Bug report template
title: "[BUG]"
labels: ''
assignees: ''

---

## Issue Description

[Provide a brief description of the issue or feature request]

## Steps to Reproduce (for bugs)

[List the steps to reproduce the issue]

## Expected Behavior

[Describe what you expected to happen]

## Actual Behavior

[Describe what actually happened]

## Additional Information

[Add any additional information, such as screenshots, error messages, or related links]
